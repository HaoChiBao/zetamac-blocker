// export const BACKEND_URL = 'http://127.0.0.1:3000';
export const BACKEND_URL = 'https://zetamac-blocker-production.up.railway.app';
